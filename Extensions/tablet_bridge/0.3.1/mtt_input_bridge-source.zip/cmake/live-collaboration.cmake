# Cryptography is linked statically into this extension, including its tests.
# OPENSSL_ROOT_DIR may select a non-system OpenSSL 3 installation.
if(EXISTS "${MTT_ROOT}/extensions/live_collaboration/CMakeLists.txt")
    set(OPENSSL_USE_STATIC_LIBS TRUE)
    if(APPLE AND NOT OPENSSL_ROOT_DIR AND EXISTS "/opt/homebrew/opt/openssl@3")
        set(OPENSSL_ROOT_DIR "/opt/homebrew/opt/openssl@3")
    endif()
    find_package(OpenSSL 3 REQUIRED COMPONENTS SSL Crypto)
    find_package(Threads REQUIRED)
    add_library(mtt_collaboration_network INTERFACE)
    target_link_libraries(mtt_collaboration_network INTERFACE
        OpenSSL::SSL OpenSSL::Crypto Threads::Threads)
    # DNSService* is exported by macOS libSystem; no separate libdns_sd exists
    # in current Apple SDKs.
    if(APPLE)
        target_link_libraries(mtt_collaboration_network INTERFACE objc)
    endif()
endif()
