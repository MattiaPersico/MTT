include_guard(GLOBAL)

# ============================================================================
#  CPack packaging. Produces a per-platform installer that drops the built
#  extensions into the REAPER UserPlugins folder.
#     macOS   -> .pkg / .tar.gz
#     Windows -> .zip (NSIS also available if installed)
#     Linux   -> .tar.gz / .deb
#  Build a package with:  cpack --config build/<preset>/CPackConfig.cmake
# ============================================================================

set(CPACK_PACKAGE_NAME "MTT-ReaperExtensions")
set(CPACK_PACKAGE_VENDOR "${MTT_VENDOR}")
set(CPACK_PACKAGE_VERSION "${MTT_VERSION}")
set(CPACK_PACKAGE_DESCRIPTION_SUMMARY "MTT REAPER extensions bundle")
set(CPACK_PACKAGE_CONTACT "mattia.persico@outlook.com")

if(WIN32)
    set(CPACK_GENERATOR "ZIP")
elseif(APPLE)
    set(CPACK_GENERATOR "TGZ")
else()
    set(CPACK_GENERATOR "TGZ")
    set(CPACK_DEBIAN_PACKAGE_MAINTAINER "${CPACK_PACKAGE_CONTACT}")
endif()

include(CPack)
