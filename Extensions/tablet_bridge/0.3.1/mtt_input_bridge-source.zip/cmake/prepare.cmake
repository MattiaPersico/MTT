include_guard(GLOBAL)
include(FetchContent)

# Reuse already-populated dependency sources across build-dir resets, so that
# a "delete build/ and reconfigure" does not re-clone the SDK every time.
if(FETCHCONTENT_BASE_DIR)
    file(
        GLOB _fetchcontent_source_dirs
        LIST_DIRECTORIES true
        "${FETCHCONTENT_BASE_DIR}/*-src"
    )
    foreach(_source_dir IN LISTS _fetchcontent_source_dirs)
        cmake_path(GET _source_dir FILENAME _content_name)
        string(REGEX REPLACE "-src$" "" _content_name "${_content_name}")
        string(TOUPPER "${_content_name}" _content_name_upper)
        set("FETCHCONTENT_SOURCE_DIR_${_content_name_upper}"
            "${_source_dir}"
            CACHE PATH
            "Override ${_content_name} FetchContent source dir"
        )
    endforeach()
endif()

# ---- Version metadata (derived from git tags, with a safe fallback) ---------
set(MTT_VERSION "0.1.0")
set(MTT_VERSION_TWEAK "0")
set(MTT_VERSION_BUILD "0")
set(MTT_VERSION_COMMIT "unknown")
set(MTT_VERSION_BRANCH "unknown")

find_package(Git QUIET)
if(Git_FOUND)
    execute_process(
        COMMAND ${GIT_EXECUTABLE} describe --tags --abbrev=0
        WORKING_DIRECTORY ${CMAKE_CURRENT_LIST_DIR}/..
        OUTPUT_VARIABLE _git_tag
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(_git_tag MATCHES "^v?([0-9]+\\.[0-9]+\\.[0-9]+)")
        set(MTT_VERSION "${CMAKE_MATCH_1}")
    endif()

    execute_process(
        COMMAND ${GIT_EXECUTABLE} rev-parse --short HEAD
        WORKING_DIRECTORY ${CMAKE_CURRENT_LIST_DIR}/..
        OUTPUT_VARIABLE _git_commit
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(_git_commit)
        set(MTT_VERSION_COMMIT "${_git_commit}")
    endif()

    execute_process(
        COMMAND ${GIT_EXECUTABLE} rev-parse --abbrev-ref HEAD
        WORKING_DIRECTORY ${CMAKE_CURRENT_LIST_DIR}/..
        OUTPUT_VARIABLE _git_branch
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(_git_branch)
        set(MTT_VERSION_BRANCH "${_git_branch}")
    endif()

    # Install the repo git hooks (formatting checks) if present.
    if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/../.git" AND IS_DIRECTORY "${CMAKE_CURRENT_LIST_DIR}/../.githooks")
        execute_process(
            COMMAND ${GIT_EXECUTABLE} config core.hooksPath .githooks
            WORKING_DIRECTORY ${CMAKE_CURRENT_LIST_DIR}/..
            OUTPUT_QUIET ERROR_QUIET
        )
    endif()
endif()

# CI build number, if available.
if(DEFINED ENV{GITHUB_RUN_NUMBER} AND NOT "$ENV{GITHUB_RUN_NUMBER}" STREQUAL "")
    set(MTT_VERSION_BUILD "$ENV{GITHUB_RUN_NUMBER}")
endif()

string(REPLACE "." ";" _version_parts "${MTT_VERSION}")
list(GET _version_parts 0 MTT_VERSION_MAJOR)
list(GET _version_parts 1 MTT_VERSION_MINOR)
list(GET _version_parts 2 MTT_VERSION_PATCH)

message(STATUS "MTT REAPER Extensions version ${MTT_VERSION} (${MTT_VERSION_BRANCH}@${MTT_VERSION_COMMIT})")
