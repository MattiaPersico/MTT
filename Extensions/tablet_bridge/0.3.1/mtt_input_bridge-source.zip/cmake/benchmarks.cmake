include_guard(GLOBAL)
include(FetchContent)

# Google Benchmark for micro-benchmarks. Only fetched when MTT_BUILD_BENCHMARKS=ON.
set(BENCHMARK_ENABLE_TESTING OFF CACHE BOOL "" FORCE)
set(BENCHMARK_ENABLE_INSTALL OFF CACHE BOOL "" FORCE)
FetchContent_Declare(
    benchmark
    GIT_REPOSITORY https://github.com/google/benchmark
    GIT_TAG "v1.9.0"
    GIT_SHALLOW TRUE
    SYSTEM
)
FetchContent_MakeAvailable(benchmark)
