include_guard(GLOBAL)

option(MTT_ENABLE_CLANG_TIDY "Run clang-tidy on extension core libraries" OFF)

# Enable clang-tidy for a target when MTT_ENABLE_CLANG_TIDY is ON and the
# clang-tidy executable is available.
function(mtt_enable_clang_tidy target)
    if(NOT MTT_ENABLE_CLANG_TIDY)
        return()
    endif()
    if(NOT _MTT_CLANG_TIDY_EXE)
        find_program(_MTT_CLANG_TIDY_EXE NAMES clang-tidy)
    endif()
    if(_MTT_CLANG_TIDY_EXE)
        set_target_properties(${target} PROPERTIES
            CXX_CLANG_TIDY "${_MTT_CLANG_TIDY_EXE}")
    else()
        message(WARNING "MTT_ENABLE_CLANG_TIDY is ON but clang-tidy was not found.")
    endif()
endfunction()
