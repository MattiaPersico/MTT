include_guard(GLOBAL)
include(FetchContent)

# GoogleTest for unit tests. Fetched once and shared by all extensions.
FetchContent_Declare(
    googletest
    GIT_REPOSITORY https://github.com/google/googletest
    GIT_TAG "v1.15.2"
    GIT_SHALLOW TRUE
    SYSTEM
)
# Do not override this project's compiler/linker settings on Windows.
set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
FetchContent_MakeAvailable(googletest)
