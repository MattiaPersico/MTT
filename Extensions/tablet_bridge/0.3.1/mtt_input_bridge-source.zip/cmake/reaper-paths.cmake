include_guard(GLOBAL)

# ============================================================================
#  Resolve the per-user REAPER "UserPlugins" folder and a normalized arch name.
# ============================================================================

# Architecture suffix appended to the plugin file name, e.g.
# reaper_hello_world-arm64.dylib. REAPER uses this to pick the right binary.
if(CMAKE_OSX_ARCHITECTURES)
    list(JOIN CMAKE_OSX_ARCHITECTURES "-" MTT_ARCH)
elseif(MSVC_CXX_ARCHITECTURE_ID)
    set(MTT_ARCH "${MSVC_CXX_ARCHITECTURE_ID}")
else()
    set(MTT_ARCH "${CMAKE_SYSTEM_PROCESSOR}")
endif()
string(TOLOWER "${MTT_ARCH}" MTT_ARCH)

# Per-user REAPER resource path.
if(WIN32)
    file(TO_CMAKE_PATH "$ENV{APPDATA}" _reaper_appdata)
    set(MTT_REAPER_RESOURCE_DIR "${_reaper_appdata}/REAPER")
elseif(APPLE)
    set(MTT_REAPER_RESOURCE_DIR "$ENV{HOME}/Library/Application Support/REAPER")
else()
    set(MTT_REAPER_RESOURCE_DIR "$ENV{HOME}/.config/REAPER")
endif()

set(MTT_REAPER_USERPLUGINS_DIR "${MTT_REAPER_RESOURCE_DIR}/UserPlugins"
    CACHE PATH "REAPER UserPlugins folder where extensions are installed")

# Used by CPack: install prefix points at the REAPER resource dir.
set(CMAKE_INSTALL_PREFIX "${MTT_REAPER_RESOURCE_DIR}" CACHE PATH "" FORCE)

message(STATUS "REAPER UserPlugins: ${MTT_REAPER_USERPLUGINS_DIR} (arch: ${MTT_ARCH})")
