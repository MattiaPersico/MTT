# cmake/

The build logic for the whole monorepo. A change here affects every extension and
every library — edit conservatively and rebuild everything afterwards.

- `add_reaper_extension.cmake` — the helper every extension calls. It builds
  `<name>_core` (static: all `src/*.cpp` except `main.cpp`), `<name>` (the shared
  module, named `reaper_<name>-<arch>`) and `<name>_tests`; generates the
  per-extension `config.h` from `config.h.in`; installs into REAPER
  `UserPlugins` after each build; wires CPack, clang-tidy and benchmarks.
- `prepare.cmake` (`MTT_VERSION`), `reaper-sdk.cmake` (fetches reaper-sdk + WDL
  and exposes the `reaper-sdk` target), `compiler.cmake` (`mtt_set_warnings()`),
  `reaper-paths.cmake` (`MTT_REAPER_USERPLUGINS_DIR`, `MTT_ARCH`), `tests.cmake`
  (GoogleTest), `benchmarks.cmake`, `clang-tidy.cmake`, `packaging.cmake` (CPack,
  included last on purpose).
- `config.h.in` is the template for the generated per-extension `config.h`
  (`PROJECT_NAME`, `PROJECT_VENDOR`, version macros). A macro added here reaches
  every extension.
- **Any edit here requires a full CMake Configure**, not just a build.
- `live-collaboration.cmake` resolves static OpenSSL 3 and Threads for the
  `mtt_collaboration_network` interface target used by `live_collaboration`.
  It does not change the dependencies of other extension cores.
- Options are declared in the root `CMakeLists.txt`, not here:
  `MTT_INSTALL_TO_REAPER` (ON), `MTT_BUILD_TESTS` (ON), `MTT_BUILD_BENCHMARKS`
  (OFF), `MTT_ENABLE_CLANG_TIDY` (OFF). Auto-install is forced OFF when the `CI`
  environment variable is set — keep that guard.
- Presets (macOS/Windows/Linux, Debug/Release) live in `CMakePresets.json` at the
  root. `cmake.copyCompileCommands` puts `compile_commands.json` at the root for
  clangd; that file is gitignored.
