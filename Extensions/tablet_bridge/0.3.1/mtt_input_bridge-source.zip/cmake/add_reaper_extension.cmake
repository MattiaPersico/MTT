include_guard(GLOBAL)

# ============================================================================
#  add_reaper_extension(<name> [LIBS lib1 lib2 ...] [NO_TESTS])
#
#  Call this from extensions/<name>/CMakeLists.txt. It expects:
#     src/main.cpp        - the DLL entry point (REAPER_PLUGIN_ENTRYPOINT)
#     src/*.cpp           - the rest of the implementation (compiled as a
#                           static "core" library so it can be unit-tested)
#     tests/*.cpp         - optional GoogleTest sources (linked against core)
#
#  It produces:
#     <name>_core         - static library with the business logic
#     <name>              - the SHARED module REAPER loads
#                           (reaper_<name>-<arch>.dylib/.dll/.so)
#     <name>_tests        - test executable (if tests/ exists and tests enabled)
#
#  Options:
#     LIBS      - shared libraries from libs/ to link into the core
#     TEST_LIBS - libraries linked ONLY into <name>_tests (e.g. mtt_testhost).
#                 Never put a test-only library in LIBS: LIBS goes into the
#                 core, and the core goes into the module REAPER ships.
#     NO_TESTS  - do not build a test target for this extension
# ============================================================================
function(add_reaper_extension name)
    cmake_parse_arguments(ARG "NO_TESTS" "" "LIBS;TEST_LIBS" ${ARGN})

    set(_dir "${CMAKE_CURRENT_SOURCE_DIR}")

    if(NOT EXISTS "${_dir}/src/main.cpp")
        message(FATAL_ERROR "add_reaper_extension(${name}): missing ${_dir}/src/main.cpp")
    endif()

    # ---- Per-extension config.h -------------------------------------------
    set(EXT_NAME "${name}")
    set(EXT_VENDOR "${MTT_VENDOR}")
    configure_file("${MTT_ROOT}/cmake/config.h.in" "${CMAKE_CURRENT_BINARY_DIR}/config.h" @ONLY)

    # ---- Core static library (everything except main.cpp) ------------------
    file(GLOB_RECURSE _core_sources CONFIGURE_DEPENDS "${_dir}/src/*.cpp")
    list(FILTER _core_sources EXCLUDE REGEX "main\\.cpp$")

    add_library(${name}_core STATIC ${_core_sources})
    target_include_directories(${name}_core PUBLIC
        "${CMAKE_CURRENT_BINARY_DIR}"   # generated config.h
        "${_dir}/src"
    )
    target_link_libraries(${name}_core PUBLIC reaper-sdk ${ARG_LIBS})
    set_target_properties(${name}_core PROPERTIES
        POSITION_INDEPENDENT_CODE ON
        CXX_VISIBILITY_PRESET hidden
        VISIBILITY_INLINES_HIDDEN ON
    )
    mtt_set_warnings(${name}_core)

    # ---- The shared module REAPER loads ------------------------------------
    add_library(${name} SHARED "${_dir}/src/main.cpp")
    target_link_libraries(${name} PRIVATE ${name}_core)
    set_target_properties(${name} PROPERTIES
        PREFIX ""                                     # no "lib" prefix
        OUTPUT_NAME "reaper_${name}-${MTT_ARCH}"
        CXX_VISIBILITY_PRESET hidden
        VISIBILITY_INLINES_HIDDEN ON
    )
    mtt_set_warnings(${name})

    # ---- Install rules (used by CPack) -------------------------------------
    install(TARGETS ${name}
        LIBRARY DESTINATION "UserPlugins"   # macOS .dylib / Linux .so
        RUNTIME DESTINATION "UserPlugins"   # Windows .dll
    )
    if(WIN32)
        install(FILES $<TARGET_PDB_FILE:${name}> DESTINATION "UserPlugins" OPTIONAL)
    endif()

    # ---- Auto-install into the local REAPER after each build ---------------
    if(MTT_INSTALL_TO_REAPER)
        add_custom_command(TARGET ${name} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E make_directory "${MTT_REAPER_USERPLUGINS_DIR}"
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                "$<TARGET_FILE:${name}>" "${MTT_REAPER_USERPLUGINS_DIR}/"
            COMMENT "Installing ${name} into REAPER UserPlugins"
            VERBATIM
        )
    endif()

    # ---- Optional clang-tidy on the core -----------------------------------
    mtt_enable_clang_tidy(${name}_core)

    # ---- Unit tests --------------------------------------------------------
    if(MTT_BUILD_TESTS AND NOT ARG_NO_TESTS)
        file(GLOB _test_sources CONFIGURE_DEPENDS "${_dir}/tests/*.cpp")
        if(_test_sources)
            add_executable(${name}_tests ${_test_sources})
            target_link_libraries(${name}_tests PRIVATE ${name}_core GTest::gtest_main ${ARG_TEST_LIBS})
            mtt_set_warnings(${name}_tests)
            include(GoogleTest)
            gtest_discover_tests(${name}_tests)
        endif()
    endif()

    # ---- Optional benchmarks ----------------------------------------------
    if(MTT_BUILD_BENCHMARKS)
        file(GLOB _bench_sources CONFIGURE_DEPENDS "${_dir}/benchmarks/*.cpp")
        if(_bench_sources)
            add_executable(${name}_benchmarks ${_bench_sources})
            target_link_libraries(${name}_benchmarks PRIVATE ${name}_core benchmark::benchmark_main)
            mtt_set_warnings(${name}_benchmarks)
        endif()
    endif()

    message(STATUS "Extension: ${name} -> reaper_${name}-${MTT_ARCH}")
endfunction()
