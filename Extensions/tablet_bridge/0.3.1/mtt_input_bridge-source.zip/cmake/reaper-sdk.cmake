include_guard(GLOBAL)
include(FetchContent)

# ============================================================================
#  Fetch the REAPER SDK (reaper-sdk + WDL) once and expose an interface target
#  named `reaper-sdk`. Every extension links against this to get the headers.
#
#  Override the tags/urls from the command line if you need to pin versions:
#    -DFETCHCONTENT_SOURCE_DIR_WDL=/path/to/WDL
#    -DFETCHCONTENT_SOURCE_DIR_REAPER_SDK=/path/to/reaper-sdk
# ============================================================================

FetchContent_Declare(
    WDL
    GIT_REPOSITORY https://github.com/justinfrankel/WDL
    GIT_TAG "origin/main"
    GIT_SHALLOW TRUE
    SYSTEM
)

FetchContent_Declare(
    reaper_sdk
    GIT_REPOSITORY https://github.com/justinfrankel/reaper-sdk
    GIT_TAG "origin/main"
    GIT_SHALLOW TRUE
    SYSTEM
)

FetchContent_MakeAvailable(WDL reaper_sdk)

FetchContent_GetProperties(WDL SOURCE_DIR _wdl_source_dir)
FetchContent_GetProperties(reaper_sdk SOURCE_DIR _reaper_sdk_source_dir)

if(NOT _wdl_source_dir OR NOT EXISTS "${_wdl_source_dir}/WDL")
    message(FATAL_ERROR "WDL source was not fetched correctly (${_wdl_source_dir}).")
endif()
if(NOT _reaper_sdk_source_dir OR NOT EXISTS "${_reaper_sdk_source_dir}/sdk")
    message(FATAL_ERROR "reaper-sdk source was not fetched correctly (${_reaper_sdk_source_dir}).")
endif()

# The REAPER SDK expects the WDL tree to live alongside it. Create a symlink
# so that #include "WDL/..." resolves from the sdk headers.
if(NOT EXISTS "${_reaper_sdk_source_dir}/WDL")
    execute_process(
        COMMAND ${CMAKE_COMMAND} -E create_symlink
            "${_wdl_source_dir}/WDL" "${_reaper_sdk_source_dir}/WDL"
        ERROR_QUIET
    )
endif()

if(NOT TARGET reaper-sdk)
    add_library(reaper-sdk INTERFACE)
    target_include_directories(
        reaper-sdk SYSTEM INTERFACE
        "${_reaper_sdk_source_dir}/sdk"
        "${_wdl_source_dir}"
        "${CMAKE_CURRENT_LIST_DIR}/../third_party/reaper_helpers"  # vendored reaper_vararg.h
    )
    if(WIN32)
        target_compile_definitions(reaper-sdk INTERFACE NOMINMAX UNICODE _CRT_SECURE_NO_WARNINGS)
    endif()
endif()

# Expose the source dirs to the rest of the build.
set(MTT_WDL_DIR "${_wdl_source_dir}" CACHE INTERNAL "WDL source dir")
set(MTT_REAPER_SDK_DIR "${_reaper_sdk_source_dir}" CACHE INTERNAL "reaper-sdk source dir")
