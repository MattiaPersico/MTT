# MTT Input Bridge corresponding source

This archive contains the exact working sources used for this release, including
the OpenTabletDriver-derived files and the SDK, WDL and GoogleTest dependency
sources. It includes uncommitted source changes when present at packaging time.
No tablet database generator or network download is needed to rebuild it.

Requirements: macOS 11+, Xcode command-line tools, CMake 3.24+ and Ninja.
From the extracted archive root, use arm64 or x86_64 as ARCH:

```sh
ARCH=arm64
cmake -S . -B build-$ARCH -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=$ARCH -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0 \
  -DMTT_INSTALL_TO_REAPER=OFF -DMTT_BUILD_TESTS=OFF \
  -DMTT_BUILD_BENCHMARKS=OFF -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
  -DFETCHCONTENT_SOURCE_DIR_WDL="$PWD/deps/wdl" \
  -DFETCHCONTENT_SOURCE_DIR_REAPER_SDK="$PWD/deps/reaper_sdk" \
  -DFETCHCONTENT_SOURCE_DIR_GOOGLETEST="$PWD/deps/googletest"
cmake --build build-$ARCH --target tablet_bridge
codesign --force --sign - build-$ARCH/extensions/tablet_bridge/reaper_tablet_bridge-$ARCH.dylib
```

Modify the derived files and rebuild/relink using the same commands. The module
is not installed by this build. The extension's README describes its operation
and hardware-validation limits. See its third-party notices and license texts.
